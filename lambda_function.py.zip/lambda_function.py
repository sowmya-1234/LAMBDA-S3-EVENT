
def lambda_handler(event, context):
    print('Trigger by Sowmya')
    return 'python lambda'

